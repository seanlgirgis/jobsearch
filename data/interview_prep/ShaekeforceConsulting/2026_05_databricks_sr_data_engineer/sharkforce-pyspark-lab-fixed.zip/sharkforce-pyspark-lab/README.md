# Sharkforce PySpark Lab

Local PySpark/Jupyter lab for interview practice. This is not Databricks running locally. It is a local Spark environment for practicing DataFrames, transformations, data quality checks, deduplication, Parquet/Delta concepts, and pytest.

## Build

```powershell
cd D:\Workarea\StudyBook\docker\sharkforce-pyspark-lab
docker compose build --no-cache
```

## Run

```powershell
docker compose up
```

Open:

```text
http://localhost:8888/lab
```

## Verify inside container

```powershell
docker exec -it sharkforce-pyspark-lab bash
```

Inside container:

```bash
java -version
python --version
python -c "import pyspark; print(pyspark.__version__)"
python -c "import delta; print('delta ok')"
```

Expected:

- Java 17
- Python 3.12.x
- PySpark 3.5.4
- delta import works

## Persistence

These container paths persist to the local D: drive because they are mounted by Docker Compose:

```text
/workspace/notebooks -> ./notebooks
/workspace/data      -> ./data
/workspace/src       -> ./src
/workspace/tests     -> ./tests
/workspace/outputs   -> ./outputs
```

Save Delta files under:

```text
/workspace/data/delta
```

Save notebooks under:

```text
/workspace/notebooks
```

## Build Notes

- Uses `python:3.12-bookworm` instead of floating `python:3.12-slim` to avoid Debian trixie package drift.
- Uses `openjdk-17-jre-headless`, which is available in Debian bookworm and is a good fit for Spark 3.5.x.
- Uses pip-installed PySpark instead of manually downloading Spark.
- This keeps the image simpler and avoids mismatch between a manually installed Spark distribution and the PySpark Python package.
